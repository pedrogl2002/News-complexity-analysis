import spacy
import os
import csv

# --- Setup ---
# We keep 'tagger' (needed to find Adverbs) but disable 'parser' and 'ner' for speed.
try:
    nlp = spacy.load("en_core_web_sm", disable=["ner", "parser"])
except OSError:
    print("Error: Model not found. Please run: python -m spacy download en_core_web_sm")
    exit()

def get_feature_rate(filename):
    """
    Calculates the percentage of words in the text that are Features.
    Formula: (Count of Features / Total Word Count) * 100
    """
    filename = filename.strip()
    
    if not os.path.exists(filename):
        return 0.0

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
            
        doc = nlp(text)
        
        feature_count = 0
        total_word_count = 0
        
        for token in doc:
            # We only count actual words (exclude punctuation/numbers) for the denominator
            if token.is_alpha:
                total_word_count += 1
                
                # Check if the tag is Feature
                if token.pos_ in ["NOUN","PROPN"]:
                    feature_count += 1
        
        # Calculate Rate
        if total_word_count > 0:
            rate = (feature_count / total_word_count) * 100
            return round(rate, 2)
        else:
            return 0.0

    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return 0.0

def process_to_csv(input_filename, text_dir, output_filename):
    if not os.path.exists(input_filename):
        print(f"Error: Input file '{input_filename}' not found.")
        return

    print(f"Calculating Feature Rate for files in '{input_filename}'...")

    try:
        with open(input_filename, 'r', encoding='utf-8') as f_in, \
             open(output_filename, 'w', newline='', encoding='utf-8') as f_out:
            
            writer = csv.writer(f_out)
            header_written = False
            
            for line in f_in:
                parts = line.strip().split(',')
                if not parts: continue
                
                identifier = parts[0]
                file_list = parts[1:]
                
                # --- Header Generation ---
                if not header_written:
                    header = ['Identifier','Loc','Nat','Int']
                    #for i in range(len(file_list)):
                    #    # Creating column headers like "File_1_Adj_Rate_%"
                    #    header.append(f"File_{i+1}_Adj_Rate_%")
                    writer.writerow(header)
                    header_written = True
                
                # --- Row Processing ---
                row_data = [identifier]
                
                for file_name in file_list:
                    file_name =  os.path.join(text_dir,file_name + '.txt')
                    feature_rate = get_feature_rate(file_name)
                    row_data.append(feature_rate)
                
                writer.writerow(row_data)

        print(f"Success! Results saved to '{output_filename}'.")

    except Exception as e:
        print(f"An error occurred: {e}")

# --- Usage ---
if __name__ == "__main__":
    # Define your input and output file names here
    input_filename = 'news_01_local.txt'
    text_dir = '../cleaned_articles_0/'
    output_dir = '../metrics/'
    output_filename = os.path.join(output_dir,'compute_noun_rate.csv')
    # 1. Create dummy files (Optional setup)
    #with open('File001.txt', 'w') as f: f.write("The quick brown fox is fast.")
    #with open('File002.txt', 'w') as f: f.write("A large, scary, and very angry bear.")
    #with open('File003.txt', 'w') as f: f.write("Good.")
    #with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt,File003.txt")

    # 2. Run the processor
    process_to_csv(input_filename, text_dir, output_filename)