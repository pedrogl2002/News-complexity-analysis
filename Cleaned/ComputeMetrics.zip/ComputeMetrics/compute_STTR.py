import spacy
import os
import csv
import statistics

# --- Setup ---
# We disable 'ner', 'parser', and 'tagger' because STTR only needs the Tokenizer.
# This makes the script run extremely fast.
try:
    nlp = spacy.load("en_core_web_sm", disable=["ner", "parser"])
except OSError:
    print("Error: Model not found. Please run: python -m spacy download en_core_web_sm")
    exit()

def calculate_sttr(filename, window_size):
    """
    Calculates the Standardized Type-to-Token Ratio (STTR).
    
    1. Reads the file.
    2. Tokenizes and keeps only alpha words (removes punctuation/numbers).
    3. Chunks the text into blocks of 'window_size'.
    4. Calculates TTR for each block and returns the average.
    """
    filename = filename.strip()
    
    if not os.path.exists(filename):
        return 0.0

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
            
        doc = nlp(text)
        
        # Filter tokens:
        # 1. strictly alphanumeric (.is_alpha)
        # 2. Convert to lowercase for accurate unique counts
        tokens = [token.lemma_.lower() for token in doc if token.is_alpha]
        
        # --- Algorithm for STTR ---
        if not tokens:
            return 0.0
            
        # If text is shorter than 1 window, return raw TTR (fallback)
        if len(tokens) < window_size:
            unique_types = set(tokens)
            return round(len(unique_types) / len(tokens), 4)

        ttr_scores = []
        
        # Step through the tokens in increments of 'window_size'
        for i in range(0, len(tokens), window_size):
            chunk = tokens[i : i + window_size]
            
            # CRITICAL: We only calculate if the chunk is full.
            # If the last chunk is 400 words (and window is 1000), 
            # including it would artificially inflate the score.
            if len(chunk) == window_size:
                unique_types = set(chunk)
                ttr = len(unique_types) / len(chunk)
                ttr_scores.append(ttr)

        # Return average of the valid chunks
        if ttr_scores:
            return round(statistics.mean(ttr_scores), 4)
        else:
            return 0.0

    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return 0.0

def process_to_csv(input_filename, text_dir, output_filename):
    if not os.path.exists(input_filename):
        print(f"Error: Input file '{input_filename}' not found.")
        return

    print(f"Computing STTR for files listed in '{input_filename}'...")

    try:
        with open(input_filename, 'r', encoding='utf-8') as f_in, \
             open(output_filename, 'w', newline='', encoding='utf-8') as f_out:
            
            writer = csv.writer(f_out)
            header_written = False
            
            for line in f_in:
                parts = line.strip().split(',')
                if not parts: continue
                
                identifier = parts[0]
                file_list = parts[1:]
                
                # --- Header Generation ---
                if not header_written:
                    header = ['Identifier','Loc','Nat','Int']
                    #for i in range(len(file_list)):
                    #    header.append(f"File_{i+1}_STTR")
                    writer.writerow(header)
                    header_written = True
                
                # --- Row Processing ---
                row_data = [identifier]
                
                for file_name in file_list:
                    file_name = os.path.join(text_dir, file_name + '.txt')
                    sttr_value = calculate_sttr(file_name, window_size = 200)
                    row_data.append(sttr_value)
                
                writer.writerow(row_data)

        print(f"Success! STTR results saved to '{output_filename}'.")

    except Exception as e:
        print(f"An error occurred: {e}")

# --- Usage ---
if __name__ == "__main__":
    # Define your input and output file names here
    input_filename = 'news_01_local.txt'
    text_dir = '../cleaned_articles_0/'
    output_dir = '../metrics/'
    output_filename = os.path.join(output_dir,'compute_sttr.csv')
    # 1. Create dummy files (Optional setup)
    #with open('File001.txt', 'w') as f: f.write("The quick brown fox is fast.")
    #with open('File002.txt', 'w') as f: f.write("A large, scary, and very angry bear.")
    #with open('File003.txt', 'w') as f: f.write("Good.")
    #with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt,File003.txt")
    # Run
    process_to_csv(input_filename, text_dir, output_filename)