import spacy
import os
import csv

# --- Setup ---
# We keep 'tagger' (needed to identify Nouns) but disable 'parser' and 'ner' for speed.
try:
    nlp = spacy.load("en_core_web_sm", disable=["ner", "parser"])
except OSError:
    print("Error: Model not found. Please run: python -m spacy download en_core_web_sm")
    exit()

def get_nominalisation_metrics(filename):
    """
    Calculates the number of nominalisations and the percentage relative to total words.
    
    Heuristic:
    1. Word must be a NOUN or PROPER NOUN.
    2. Word must end with a nominalisation suffix (e.g., -tion, -ment).
    3. Word must be longer than 4 characters (to avoid noise).
    """
    filename = filename.strip()
    
    # Default return values
    metrics = {
        "Nom_Count": 0,
        "Nom_Rate": 0.0,  # Percentage of total words
        "Total_Words": 0
    }
    
    if not os.path.exists(filename):
        return metrics

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
            
        doc = nlp(text)
        
        # 1. Define Nominalisation Suffixes
        # These are the standard morphological endings that turn verbs/adjectives into nouns.
        nom_suffixes = ('tion', 'ment', 'ence', 'ance', 'ity', 'ness', 'sion', 'ship', 'ism', 'hood')
        
        nom_count = 0
        
        # Filter for actual words (ignore punctuation/numbers) for the total count
        words = [token for token in doc if token.is_alpha]
        total_word_count = len(words)
        
        # 2. Iterate and Check
        for token in doc:
            # Must be a Noun
            if token.pos_ in ["NOUN", "PROPN"]:
                text_lower = token.text.lower()
                
                # Must end with suffix AND be long enough to be valid
                if text_lower.endswith(nom_suffixes) and len(text_lower) > 4:
                    nom_count += 1

        # 3. Calculate Rate
        metrics["Nom_Count"] = nom_count
        metrics["Total_Words"] = total_word_count
        
        if total_word_count > 0:
            metrics["Nom_Rate"] = round((nom_count / total_word_count) * 100, 2)

        return metrics

    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return metrics

def process_to_csv(input_filename, text_dir, output_filename):
    if not os.path.exists(input_filename):
        print(f"Error: Input file '{input_filename}' not found.")
        return

    print(f"Calculating Nominalisation for files in '{input_filename}'...")

    try:
        with open(input_filename, 'r', encoding='utf-8') as f_in, \
             open(output_filename, 'w', newline='', encoding='utf-8') as f_out:
            
            writer = csv.writer(f_out)
            header_written = False
            
            for line in f_in:
                parts = line.strip().split(',')
                if not parts: continue
                
                identifier = parts[0]
                file_list = parts[1:]
                
                # --- Header Generation ---
                if not header_written:
                    header = ['Identifier','Loc','Nat','Int']
                    #for i in range(len(file_list)):
                    #    prefix = f"File_{i+1}"
                    #    # We output Count and Rate (Percentage)
                    #    header.append(f"{prefix}_Nom_Count")
                    #    header.append(f"{prefix}_Nom_Rate_%")
                    writer.writerow(header)
                    header_written = True
                
                # --- Row Processing ---
                row_data = [identifier]
                
                for file_name in file_list:
                    file_name =  os.path.join(text_dir,file_name + '.txt')
                    res = get_nominalisation_metrics(file_name)
                    #row_data.append(res["Nom_Count"])
                    row_data.append(res["Nom_Rate"])
                
                writer.writerow(row_data)

        print(f"Success! Results saved to '{output_filename}'.")

    except Exception as e:
        print(f"An error occurred: {e}")

# --- Usage ---
if __name__ == "__main__":
    # Define your input and output file names here
    input_filename = 'news_01_local.txt'
    text_dir = '../cleaned_articles_0/'
    output_dir = '../metrics/'
    output_filename = os.path.join(output_dir,'compute_nominal.csv')
    # 1. Create dummy files (Optional setup)
    #with open('File001.txt', 'w') as f: f.write("The quick brown fox is fast.")
    #with open('File002.txt', 'w') as f: f.write("A large, scary, and very angry bear.")
    #with open('File003.txt', 'w') as f: f.write("Good.")
    #with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt,File003.txt")
    # Run
    process_to_csv(input_filename, text_dir, output_filename)