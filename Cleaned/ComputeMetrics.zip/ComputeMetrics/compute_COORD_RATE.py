import spacy
import os
import csv

# --- Setup ---
# We enable 'parser' (critical for dependency parsing) and 'tagger'.
# We disable 'ner' (Named Entity Recognition) to save some memory/time.
try:
    nlp = spacy.load("en_core_web_sm", disable=["ner"])
except OSError:
    print("Error: Model not found. Please run: python -m spacy download en_core_web_sm")
    exit()

def get_coordinated_rate(filename):
    """
    Calculates the rate of Coordinated Sentences.
    Formula: (Number of Coordinated Sentences / Total Number of Sentences) * 100
    
    Definition of Coordinated Sentence (Heuristic):
    A sentence containing a Verb connected to another Verb via a 'conj' (conjunct) relationship.
    """
    filename = filename.strip()
    
    if not os.path.exists(filename):
        return 0.0

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
            
        doc = nlp(text)
        
        # Get total number of sentences
        # Note: doc.sents is a generator, so we convert to list to count
        sentences = list(doc.sents)
        total_sents = len(sentences)
        
        coord_sent_count = 0
        
        for sent in sentences:
            is_coordinated = False
            
            for token in sent:
                # Check for coordination logic:
                # 1. Dependency is 'conj' (connected by conjunction like 'and')
                # 2. The token itself is a VERB
                # 3. The head (parent) it connects to is also a VERB
                if (token.dep_ == "conj" and 
                    token.pos_ == "VERB" and 
                    token.head.pos_ == "VERB"):
                    
                    is_coordinated = True
                    break # Stop checking this sentence once found
            
            if is_coordinated:
                coord_sent_count += 1
        
        # Calculate Rate
        if total_sents > 0:
            rate = (coord_sent_count / total_sents) * 100
            return round(rate, 2)
        else:
            return 0.0

    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return 0.0

def process_to_csv(input_filename, text_dir, output_filename):
    if not os.path.exists(input_filename):
        print(f"Error: Input file '{input_filename}' not found.")
        return

    print(f"Calculating Coordinated Sentence Rate for files in '{input_filename}'...")

    try:
        with open(input_filename, 'r', encoding='utf-8') as f_in, \
             open(output_filename, 'w', newline='', encoding='utf-8') as f_out:
            
            writer = csv.writer(f_out)
            header_written = False
            
            for line in f_in:
                parts = line.strip().split(',')
                if not parts: continue
                
                identifier = parts[0]
                file_list = parts[1:]
                
                # --- Header Generation ---
                if not header_written:
                    header = ['Identifier','Loc','Nat','Int']
                    #for i in range(len(file_list)):
                    #    header.append(f"File_{i+1}_Coord_Sent_Rate_%")
                    writer.writerow(header)
                    header_written = True
                
                # --- Row Processing ---
                row_data = [identifier]
                
                for file_name in file_list:
                    file_name =  os.path.join(text_dir,file_name + '.txt')
                    coord_rate = get_coordinated_rate(file_name)
                    row_data.append(coord_rate)
                
                writer.writerow(row_data)

        print(f"Success! Results saved to '{output_filename}'.")

    except Exception as e:
        print(f"An error occurred: {e}")

# --- Usage ---
""" if __name__ == "__main__":
    # Test Data
    
    # File 1: 2 sentences. 
    # Sent 1: "I ran and he jumped." (Coordinated)
    # Sent 2: "I slept." (Simple)
    # Result: 1/2 = 50%
    with open('File001.txt', 'w') as f: f.write("I ran and he jumped. I slept.") 
    
    # File 2: 1 sentence. "I like apples and pears." (Noun coordination, NOT sentence coordination)
    # Result: 0/1 = 0%
    with open('File002.txt', 'w') as f: f.write("I like apples and pears.") 
    
    with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt")

    process_to_csv('records.txt', 'coordinated_rate_output.csv') """

if __name__ == "__main__":
    # Define your input and output file names here
    input_filename = 'news_01_local.txt'
    text_dir = '../cleaned_articles_0/'
    output_dir = '../metrics/'
    output_filename = os.path.join(output_dir,'compute_coord_rate.csv')
    # 1. Create dummy files (Optional setup)
    #with open('File001.txt', 'w') as f: f.write("The quick brown fox is fast.")
    #with open('File002.txt', 'w') as f: f.write("A large, scary, and very angry bear.")
    #with open('File003.txt', 'w') as f: f.write("Good.")
    #with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt,File003.txt")

    # 2. Run the processor
    process_to_csv(input_filename, text_dir, output_filename)