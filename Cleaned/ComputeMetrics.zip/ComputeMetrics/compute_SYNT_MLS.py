import spacy
import os
import csv

# --- Setup ---
# We enable 'parser' because it provides the sentence boundaries (doc.sents).
# We disable 'ner' to save memory.
try:
    nlp = spacy.load("_core_web_senm", disable=["ner"])
except OSError:
    print("Error: Model not found. Please run: python -m spacy download en_core_web_sm")
    exit()

def get_mls_score(filename):
    """
    Calculates the Mean Length of Sentence (MLS).
    Formula: Total Words / Total Sentences.
    
    Note: We exclude punctuation from the word count to ensure 
    we are measuring linguistic content, not formatting.
    """
    filename = filename.strip()
    
    if not os.path.exists(filename):
        return 0.0

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
            
        doc = nlp(text)
        
        # 1. Count Sentences
        # doc.sents is a generator, so we convert to a list to count them.
        sentences = list(doc.sents)
        n_sentences = len(sentences)
        
        # 2. Count Words
        # We filter out punctuation to get a cleaner count of actual lexical items.
        # token.is_punct checks for '.', ',', '!', etc.
        words = [token for token in doc if not token.is_punct and not token.is_space]
        n_words = len(words)
        
        # 3. Calculate MLS
        if n_sentences > 0:
            mls = n_words / n_sentences
            return round(mls, 2)
        else:
            return 0.0

    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return 0.0

def process_to_csv(input_filename, text_dir, output_filename):
    if not os.path.exists(input_filename):
        print(f"Error: Input file '{input_filename}' not found.")
        return

    print(f"Calculating MLS for files in '{input_filename}'...")

    try:
        with open(input_filename, 'r', encoding='utf-8') as f_in, \
             open(output_filename, 'w', newline='', encoding='utf-8') as f_out:
            
            writer = csv.writer(f_out)
            header_written = False
            
            for line in f_in:
                parts = line.strip().split(',')
                if not parts: continue
                
                identifier = parts[0]
                file_list = parts[1:]
                
                # --- Header Generation ---
                if not header_written:
                    header = ['Identifier','Loc','Nat','Int']
                    #for i in range(len(file_list)):
                    #    header.append(f"File_{i+1}_MLS")
                    writer.writerow(header)
                    header_written = True
                
                # --- Row Processing ---
                row_data = [identifier]
                
                for file_name in file_list:
                    file_name =  os.path.join(text_dir,file_name + '.txt')
                    mls_val = get_mls_score(file_name)
                    row_data.append(mls_val)
                
                writer.writerow(row_data)

        print(f"Success! Results saved to '{output_filename}'.")

    except Exception as e:
        print(f"An error occurred: {e}")

# --- Usage ---
""" if __name__ == "__main__":
    # Test Data
    
    # File 1: Short/Simple. "I run. I jump."
    # 4 words / 2 sentences = MLS 2.0
    with open('File001.txt', 'w') as f: f.write("I run. I jump.") 
    
    # File 2: Long/Complex. "I run because I am late for work."
    # 8 words / 1 sentence = MLS 8.0
    with open('File002.txt', 'w') as f: f.write("I run because I am late for work.") 
    
    with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt")

    process_to_csv('records.txt', 'mls_output.csv') """
if __name__ == "__main__":
    # Define your input and output file names here
    input_filename = 'news_01_local.txt'
    text_dir = '../cleaned_articles_0/'
    output_dir = '../metrics/'
    output_filename = os.path.join(output_dir,'compute_synt_mls.csv')
    # 1. Create dummy files (Optional setup)
    #with open('File001.txt', 'w') as f: f.write("The quick brown fox is fast.")
    #with open('File002.txt', 'w') as f: f.write("A large, scary, and very angry bear.")
    #with open('File003.txt', 'w') as f: f.write("Good.")
    #with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt,File003.txt")

    # 2. Run the processor
    process_to_csv(input_filename, text_dir, output_filename)