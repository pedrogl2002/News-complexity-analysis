import spacy
import os
import csv
from wordfreq import zipf_frequency

# --- Setup ---
# We only need the Tokenizer, so we disable everything else for speed.
try:
    nlp = spacy.load("en_core_web_sm", disable=["ner"])
except OSError:
    print("Error: Model not found. Please run: python -m spacy download en_core_web_sm")
    exit()

def get_avg_zipf_score(filename):
    """
    Calculates the Average Zipf Score of a text.
    
    Logic:
    1. Tokenize text.
    2. Filter for alpha words (excluding punctuation/numbers).
    3. Look up the Zipf score for each word using 'wordfreq'.
    4. Calculate the mean.
    
    Interpretation:
    - Higher score = More common vocabulary (Simpler).
    - Lower score = More rare vocabulary (Complex/Technical).
    """
    filename = filename.strip()
    
    if not os.path.exists(filename):
        return 0.0

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
            
        doc = nlp(text)
        
        total_zipf = 0.0
        word_count = 0
        
        for token in doc:
            if token.is_alpha:
                # We use the lowercase form for frequency lookups
                word = token.text.lower()
                
                # Get Zipf score for English ('en')
                # Returns a float typically between 0 and 8
                score = zipf_frequency(word, 'en')
                
                # wordfreq returns 0.0 if the word is completely unknown.
                # We usually include these as 0 (extremely rare) or filter them.
                # Here we include them to penalize made-up words/typos.
                total_zipf += score
                word_count += 1
        
        # Calculate Average
        if word_count > 0:
            avg_score = total_zipf / word_count
            return round(avg_score, 2)
        else:
            return 0.0

    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return 0.0

def process_to_csv(input_filename, text_dir, output_filename):
    if not os.path.exists(input_filename):
        print(f"Error: Input file '{input_filename}' not found.")
        return

    print(f"Calculating Zipf Scores for files in '{input_filename}'...")

    try:
        with open(input_filename, 'r', encoding='utf-8') as f_in, \
             open(output_filename, 'w', newline='', encoding='utf-8') as f_out:
            
            writer = csv.writer(f_out)
            header_written = False
            
            for line in f_in:
                parts = line.strip().split(',')
                if not parts: continue
                
                identifier = parts[0]
                file_list = parts[1:]
                
                # --- Header Generation ---
                if not header_written:
                    header = ['Identifier','Loc','Nat','Int']
                    #for i in range(len(file_list)):
                    #    header.append(f"File_{i+1}_Avg_Zipf")
                    writer.writerow(header)
                    header_written = True
                
                # --- Row Processing ---
                row_data = [identifier]
                
                for file_name in file_list:
                    file_name =  os.path.join(text_dir,file_name + '.txt')
                    zipf_val = get_avg_zipf_score(file_name)
                    row_data.append(zipf_val)
                
                writer.writerow(row_data)

        print(f"Success! Results saved to '{output_filename}'.")

    except Exception as e:
        print(f"An error occurred: {e}")

# --- Usage ---
""" if __name__ == "__main__":
    # Test Data
    
    # File 1: Very Common Words. "The cat is good."
    # Zipf scores for these are roughly 6.0 - 7.0. Average should be high (~6.5).
    with open('File001.txt', 'w') as f: f.write("The cat is good.") 
    
    # File 2: Rare Words. "Defenestrate the bract."
    # "Defenestrate" is ~1.7. "Bract" is ~3.0. "The" is ~7.7. Average should be lower (~4.1).
    with open('File002.txt', 'w') as f: f.write("Defenestrate the bract.") 
    
    with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt")

    process_to_csv('records.txt', 'zipf_score_output.csv')
 """
if __name__ == "__main__":
    # Define your input and output file names here
    input_filename = 'news_01_local.txt'
    text_dir = '../cleaned_articles_0/'
    output_dir = '../metrics/'
    output_filename = os.path.join(output_dir, 'compute_zipf.csv')
    # 1. Create dummy files (Optional setup)
    #with open('File001.txt', 'w') as f: f.write("The quick brown fox is fast.")
    #with open('File002.txt', 'w') as f: f.write("A large, scary, and very angry bear.")
    #with open('File003.txt', 'w') as f: f.write("Good.")
    #with open('records.txt', 'w') as f: f.write("ID_01,File001.txt,File002.txt,File003.txt")

    # 2. Run the processor
    process_to_csv(input_filename, text_dir, output_filename)